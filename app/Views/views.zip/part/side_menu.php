<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../../index3.html" class="brand-link">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAMAAAC8EZcfAAAA1VBMVEX////4+PgAAADwuBDwyBDYnAjwtAjosBD4uBDQzMjAiADo5ODwxAjAwMCoaBDo7PCAWAi4kBgoIBgQEBAICADgyBjQgCDYsACwsLBISEiAaFA4ODDAeBCAgIDowIB4gBDw2LAYGBCglJDQoGAwKDCASAhAIAhoOAhYkBDgrGAwoAhAKAjItJA4LBgYEAB4XBDInFhQNAjYzKBYVFDYwIDAlDAgyBhIaBCQWBBYxBiggBCwlDDIuLAgHBDYyGignBAohCBoVDDIwJCYcCg4HDiYnJh4fHDm4xMeAAAQcklEQVR4nO2ceX+a3BLHKzuIyOZlNRarkiYmJtE2TfIkXe99/y/pzsw54IYtBJ+P+aNjRGMqfPnNchYOfffur/21v3YKEwo7NUilCVv27o1BClV2aqi1+ZV8bwfxEJ7gvw3Ew3RvQ8QDfNnEzby3gHiAz3OjKJpkpyc8FH7eJIqXQOidmPBgfgDgcBhHkzcMuBwOQUL3tIQH+YQsWYKLEwA8KeFvACeQJG6WnTaTD/MJmYvilU3MmwP0/Q260xH+RkF/p3323xrgnr15wFMQNuI7iYT80JgROzS+n2VudmrAEs93J5mwZ9kyegsKsnTNEndTP+zKuL4fJW9BQQHbDMGL1hpO4uF4PB4OMyHKTk/oR8PxfAyEk5IP8ebzXm/o+Zl/aj4hiQElHMdlZU4QLwx1XR/H4PtTK+jF41Dv9XrjIiG84VjvounheLgZgycAJH8CX78DNuQYUdjtMOuGw+WJ0xgd2uvr4zEwdnka4/uOPpyMgbM7PrGCEHbLbigIrguCIYyPgKAm5G/shkAdnVzBZX8i+OMo6XdC38OUQOWAM4Mq0107/nSAcRdooqHQ6YSe60YuApJj3aEAgPrbAMzG7rgTutAkuxkAMtl8YfgWAJdd14fS4sVMN8FLeqVfl/03ADjRI6bWPLFtezrNk3m3rDhvQUGhp2NXy7clRVKCwJSCNC5Sd/4mAJfdOWSELRuBJpmBMRoFg8CmmjiEgjg/PWDU7SQzS5YVTZIk0wwGpimZ1syNQqiN4WahPlFbJ4T9gSGrkgY+NgdouAUtB4NO58RtMSNMYkOWRcVEAQcMcRCAlEFg2O4bUNCfWo6sKmBAyPDAywE+JDHd6mcf7bj/7NlhQt9OU1lVFXAxCmgO5uhj0A8IAdX+FxT85+59hd1V8wm5le4LGHAXD6SRf2wF/6miY1ahoyCggAgIKUJ8c1DRJLzAsgJ1emwFf9zdoYBn22jw6xn84cc+HwAaCAg5bG7FX2DA5/LxAf+3urs7I0MsennPfge+/+79cwC0DaYgJTH5Fx+WIQcAKOfHTuMfq9XqBSAR8+6Mbe7uVnfw4Y/VHqCAs/lTR1VEE8rMIGDhh/XFkckMyuLJ5IgSkoAvaKsVwb68fHh5IQ1X+/8aDurmM0vVRFMaFHh2jqqCOSkTcDmM3KMRcgdXWEWSUJ1O7HykKiZrP4I0n3E8w0nj3pIBgrlHAvzn/ers5ePHj2dnH5nR6wfQ7/1ejlAdDHsx9LJGhuEYBvS3MGkQ0EgHAxiN9hDLiwEwOpaEAPixws5WFR5mgGFsWyML+AzKXHg6TpoOeroOfyOsaFgQHgFwtfrw8YaYbm4+fLjBtzfweNkvMgQo9HrhPB6NLKx8zLWyY6RxCOrpei8ck4TRESX8cfbygcg+cANG2K7O9osMAYaAMo/tETQooB162jLS+bwX9vQuakgZnETD2D8S4Mv7lw8VtnpfzYcKooa2DVxGmoKzrXgOH/VwgqHf1Xn/3y3avPaE71dVgHdVjTEBhnqP4pDbKB6gfL0uTYh0dH178jVrD3hXDVhdBXFM0tVBRRCR2Zzk0zlfp9MdbgEKXmvAFQHyMLxhbwHwAJ+ggxtRsR5tQvrRdb3gg27/dq81a024umOAN8wOA5LvJn0MNBSteABft7vm6/S3JfTaO3mFXJ/Q8IV+bm72PexnODk57gNLnwh7IT11fRMPnbx90clrnSc/v396enr69OkJGZ/w/dPT95+7/wq6CZ4nLPt9NhXIPbwZfaWE8XYUtge8/Jl+2rJ0cbWLx7SYFLGmk3gYft3Onum7V1HaEl5aafqfDUv3APmB3F6/kEvHVK6QjyRMhOMSXn3Z4gPC/L6Kj+YOykjrYm5U8XX4vNIRARcc0IAHAd5uApaHcfWtXDhAh39yj0t4D4BEZhhsk95+38fbFvD3tpsmLQkJELDWm9vFNhpZVJEPB2zPx+0I7/OUicf9DIA/948gDCszotL0imuNLQC/L3azuArQDesDbs32HwVwN4sX+wdYX7HhVo3bh9Po98cVSwxbAEKZSVN68jf5Y4WHx71NpH6/Io378GkXq0+3wsevJ/xuPULXE7ufbGM8LvYVzMbjEOtyn+vUZYVwjUufcOv39wpNO0ALxj9Pj0/FxqoAjMbj8brjAkBbdRp+xUuMzOBEOr3d5q4NIQA+WezJ33zZB8SLwps9F5Bs27mbiDq7eJJNvKMQLizrEbi+WnzzWAU4Hs97+ma3b68qopt1TgndWmSLIvcIhMLC+vL4k0HS5vHLPuBkPN/uuHQryzYxriWE4rS9/OJVfML94vGr9eULcLHN18fF/eZeUYthqO/k7KGiyHwNsUDu9beXX7yKT7jPv3xFe6QfsC+X55viwVDXC6s6focR0cm86+8lXitCBLxF4RZQXBYLVPBxQYD88jmFUdSADwwICwlxcabfglAgwMX5YpGf52Dn+WJxnm8qSK1W2AQPRcRiWFwFdds4Gb9zfgt4eQGY54t8Q0EX5zKShnycECT0vSzzJy3WghDg/fmCuPjmHD4o+DzqvtfuJawNUgXH8L6bTLIs8VsRnt/m9wh1fs9fUMHlsswQvBDc3Pp09dibRInrue0kPL+8Pb+9pSd/g4AsgCI8d/3PONWWQJVBQC/yXg0IhBcEeHl+dXlZAvL+dPZqAcmGXjaZuJkvRJPXA74DwEtgujy/vKTN7fnl88W7dQr7FQIeHjBtWZh5noeLqLKozaKu+/uLi/OLAhDf3xctCabIpOLI+y1xpfVLrDY+vrj2r++vry+4XcMv/vUD25l7oAZWt8T7VgJu1MJXACITexZvni/K/VXVwH7d4Uk5NvE3ZhuaA15eXlyuYxB+ed4AHLcBXE/FtQhCcuzV1e0DlpmHq6sr+qDcXeXsyysAX63gw/PV86+Hh4ciBuEtQBZBKLhVx+22AmxIeHF9dX318JxcgYqg3q/k+gE+KAGHlYC7ncNDNj4C4Odn4HpIkgSftEEFnz/znc2rFazH1y8X+qyXvDYHvH7eBvwFgM/XBWBlM1dbwU4J2GJ98GegQe8+/Lq6QrirK2Au+KqqdIMYLAHdrfFdU8LPQPT8/Bnr4OfnZ9h8LviEuNKZ1TOrtQEb8nHGDdvY17LSxc0BkzYK7tnGrqonBesmyRpwM0eOCnhIwbqAvP1wj7poiu2Epd24OotrA/LytzMHckTAXhVgvz4gm632E//4gDShcCTA7BhTNHuARNirPGztOt1hZO5RPbw1vX8AsFGSwLjE81z3eLdy0DnbM9pV9ZRCbcAutsIZ3hPo+ROX35p6DAWniiQq4J6opYIhNMJr4bwsYv3WtoRTGfjg4bKl+ntWP0kSf+f6OxG25YsdTZSATwMNvVcX6u4cLM+208OfHAMwCEA+UWOEry0zA9WUFE3duWrnYZPSmk+WAVCDIJQkya0eM/0RsCuzlaOD7Qqduf7UjJNWfLHjyKqKCxhBRFOdV80r/BlwLiu09DHeAvQ835MDc9CKMHVkWZUU9DI4yQyq8vjP3a25rJpaEAS7F2b96SAIBsM2Aqa4FlWTNPQwhKFkVUr4ZwVVXAQp2zsX7XIJV6XFbfhQQKwxWGhARNOc/gmmGlBURCUw7O0sdmUpGIDj2/EFqgl7J0RIRCloPj3Y74KCkmjKhrW17NY1ZAwb87UuXqapY0CGYIlBPvCwqA3MKif/1rq6DkkiiqrsWHZeaui5FmCbmqK8RsEoWqa4ypwtQgbfighJpSZo6GS8TDKXAwkADWNk5awx8V17RKvsFU1prKDlyA4a4qkKUiksBLEemorcTMJuDxVURRUAcYWhbed5PrXxmiruXoMAaoaX4PdUZMNXEdfBAxdUalARTlcyg2kjQqYgeAL26RhWaYxPMeG0G/k4xrwlU0A8eLIKgwriC7w3ZaG5guykDQdX4BqGgdEtk3+pHxI1ABwwPqSjh6kUKQKJKJkgpqQ0yhMA7M0dgwAhCg2KHoPdA2CCfzF2Bg0ASXhRw5PToKyYWGE0aOVEcoZId2aoTfIEr9QNBthg8gX0uJ4Z+aD+S9gGQPQ0cfIA4hnQNAWrCssMXqRZnwHvbQma5ElfBwUtg6/vLyxQqTyYSIl9pfqEKbUciqSZ5FmNfkRKEZEFDEpoNQEEBSEnsCbIpGLAglwp2k9qBGoTxgMZKwuemCIW4UelUGK/aVh2mkgIgDEBqjz7eA5qtFvavdaAcDkIoO3AjBC5eOQF6m1JtC8J7/Eb1ScEQJuK/hYeFggWPewVoqpet2vpcB9LPPwkjVUY5mUExTus1FEDwGRKMci5uMFpUmwrJgW2KA1q9rtizBKJRwbppylFsmjoe6zdUAxrS6hPvNyie4tUyj4TqjNrmiReGpifIC9rtSmxEyjIY2L4KqwXw50BXQ+qhsA5qO3kEBrefOSwdoMyTBG5d0TNVE0qDTzYB1oNQId8jHFLnWiJlVITd8CCGks3tHhyPSfjLRvuFAEDbDnEkoZCRZQkFk7oMjxkLQWhCy0yf9KJatSbYactYYFkIRrIcU0+ALQc7mHe5xAL3UTqxYllwNdS0FGxwmArBCHHT9oUJV654T20MyZIOPijk/tsQtC1S0AWdSwCNVZf0Vsaqza1FCQXozfpa9CVoSaEVWhWeTRKPSkwRn8YLBX3786mFs+RsluJucf7IBovFHAgtU4xJEA8Tyqk+GWNIlAT+dBJocCE4YkT/9bJ6wXUM5saEsoRXl21Ae1koxJq0KOtVawRUDPFUi2lKARlrxXD04SIlw07Pqhhbz3E9Gd2yl1M+2Unzv1cPurzOTiAMFWFe0ORylFdUWzgR1UD6JiM8qRyRq473pzH92a2gVmsKBxFY0MIPAprsEDJoB4eCYi9X9ZSKmLRjqgaV4+Fs6hQ/9OazoR4O1W6+nC5M8VLgNT/E1mXlxWtIvegSMO+6jbF1BfijSUPaaqAGt8jdnModwgwtWc4G7kcjsMwnA+Hy+0LIMXwMi8AN/xQ/ihiAzwOWHY8oEGncsjbJlaqKTI1NsSwZ1WLPw8BbsSdqbGyAianTcYkeGccu7uw7B1hw6eVocxjks7bgHFu1frZHZtNbTYGKTpY7CwZnWw0HBbDkNPAMYNjFJ1fTomqUXArPOeg827Z01ktQMvhNyJjfVYITeVh3AwPDIZc6XpoY9DdkCSmwgJco2OAhw3HqgcILrb4MA6Uw93QOUOIyMZrpt4i2x7BuBUXUTtMTYMrqbDmGUqqyvhGdl4XkFyCp8nh8B5Qw2oy3txixP9bBCmNFAV1Uj5QVGkoyoe4yDed1QGcTUeckEKbje2c1LJfy8cgo3g0GuHNkChnysbaxQFAVYtmMWa/T5J3eBnDxSCEfThsDwbRGdZo+q0NH9m3aApK2ghKcpK/KYNS4pvmxcWY38yFA2CO7oCTZIENePB1u93c9AYjnD86fMRnVNDpFuEB36zONP23JLdt8oOF0QKg+PUj8bEjwCGmqCWntOAN/f83M7fO/+/wLQEJbR4rFju7I7h3/zC5zf1tj2zOV++r7mw2LX3AYvf4fGigY3GfLri3Nh8QQhgyD4xYaPw7fO+Yt8DbU8Srz4eEiDjlws/+LTy0b8g4Azr3W6PvJeBnZg3O66/9tRPZ/wEy5u7as9WSuQAAAABJRU5ErkJggg==" alt="User Avatar" class="img-size-50 mr-3 img-circle">
      <span class="brand-text font-weight-light">Vendors</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar h-full">

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="/" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="/list" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Vendor list
                <!-- <span class="right badge badge-danger">New</span> -->
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>